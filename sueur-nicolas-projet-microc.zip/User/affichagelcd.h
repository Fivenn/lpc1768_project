/*
Fonction permettant de dessiner un rectangle de coordonn�es (x,y)
de longueur lng, de largeur lrg, d'�paisseur de trait de bordure e,
plein ou vide, de couleur de bordure e_color et de fond bg_color
*/
 void dessiner_rect(unsigned int x, unsigned int y, unsigned int lng, unsigned int lrg, unsigned int e, unsigned short plein, unsigned short e_color, unsigned short bg_color);
 void dessiner_ligne(unsigned int x, unsigned int y, unsigned int l,unsigned int e, char orientation, unsigned short color);
 
 